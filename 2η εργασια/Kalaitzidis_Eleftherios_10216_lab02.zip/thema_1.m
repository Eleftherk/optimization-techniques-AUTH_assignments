syms x y
f=x^5*exp(-x^2-y^2);
fsurf(f)
xlabel ("x")
ylabel ("y")